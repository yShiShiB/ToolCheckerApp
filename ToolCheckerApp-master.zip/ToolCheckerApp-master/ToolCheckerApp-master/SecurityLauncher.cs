﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class SecurityLauncher : Form
    {
        public SecurityLauncher()
        {
            InitializeComponent();
        }
    }
}
