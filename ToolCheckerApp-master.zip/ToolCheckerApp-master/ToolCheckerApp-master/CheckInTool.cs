﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class CheckInTool : Form
    {
        public CheckInTool()
        {
            InitializeComponent();
        }

    }
}
