﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class CheckOutTool : Form
    {
        public CheckOutTool()
        {
            InitializeComponent();
        }
    }
}
