﻿using System.Drawing;
using System.Windows.Forms;

namespace ToolCheckerApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEmpLogin = new System.Windows.Forms.Button();
            this.lblWelcomeMessage = new System.Windows.Forms.Label();
            this.btnAdminLogin = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEmpLogin
            // 
            this.btnEmpLogin.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Italic);
            this.btnEmpLogin.Location = new System.Drawing.Point(135, 143);
            this.btnEmpLogin.Margin = new System.Windows.Forms.Padding(2);
            this.btnEmpLogin.Name = "btnEmpLogin";
            this.btnEmpLogin.Size = new System.Drawing.Size(186, 67);
            this.btnEmpLogin.TabIndex = 0;
            this.btnEmpLogin.Text = "Employee Login";
            this.btnEmpLogin.UseVisualStyleBackColor = true;
            // 
            // lblWelcomeMessage
            // 
            this.lblWelcomeMessage.AutoSize = true;
            this.lblWelcomeMessage.Font = new System.Drawing.Font("Lato", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblWelcomeMessage.Location = new System.Drawing.Point(129, 37);
            this.lblWelcomeMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWelcomeMessage.Name = "lblWelcomeMessage";
            this.lblWelcomeMessage.Size = new System.Drawing.Size(423, 33);
            this.lblWelcomeMessage.TabIndex = 7;
            this.lblWelcomeMessage.Text = "Welcome to the Tool Checker App";
            // 
            // btnAdminLogin
            // 
            this.btnAdminLogin.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Italic);
            this.btnAdminLogin.Location = new System.Drawing.Point(344, 144);
            this.btnAdminLogin.Name = "btnAdminLogin";
            this.btnAdminLogin.Size = new System.Drawing.Size(186, 67);
            this.btnAdminLogin.TabIndex = 8;
            this.btnAdminLogin.Text = "Adminstrator Login";
            this.btnAdminLogin.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Italic);
            this.btnExit.Location = new System.Drawing.Point(240, 265);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(186, 67);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit Program";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 411);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdminLogin);
            this.Controls.Add(this.lblWelcomeMessage);
            this.Controls.Add(this.btnEmpLogin);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnEmpLogin;
        private Label lblWelcomeMessage;
        private Button btnAdminLogin;
        private Button btnExit;

    }
}

