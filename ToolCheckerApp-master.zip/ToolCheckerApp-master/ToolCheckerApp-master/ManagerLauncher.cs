﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class ManagerLauncher : Form
    {
        public ManagerLauncher()
        {
            InitializeComponent();
        }
    }
}
