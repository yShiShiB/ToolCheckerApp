﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class RemoveUser : Form
    {
        public RemoveUser()
        {
            InitializeComponent();
        }
    }
}
