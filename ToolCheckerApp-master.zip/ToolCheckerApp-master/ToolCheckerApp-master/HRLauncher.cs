﻿using System;
using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class HRLauncher : Form
    {
        public GenerateReport genRpt = new GenerateReport();
        public HRLauncher()
        {
            InitializeComponent();
        }

        private void btnLogout_Click_1(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1(); 
            frm1.ShowDialog();
            this.Hide();

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            genRpt.ShowDialog();
        }
    }
}
