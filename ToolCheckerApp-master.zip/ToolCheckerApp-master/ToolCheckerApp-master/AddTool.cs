﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class AddTool : Form
    {
        public AddTool()
        {
            InitializeComponent();
        }
    }
}
