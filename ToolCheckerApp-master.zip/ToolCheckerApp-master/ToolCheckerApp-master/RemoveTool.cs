﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class RemoveTool : Form
    {
        public RemoveTool()
        {
            InitializeComponent();
        }
    }
}
