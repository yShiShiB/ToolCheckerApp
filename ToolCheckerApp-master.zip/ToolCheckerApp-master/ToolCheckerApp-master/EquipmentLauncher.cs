﻿using System.Windows.Forms;

namespace ToolCheckerApp
{
    public partial class EquipmentLauncher : Form
    {
        public EquipmentLauncher()
        {
            InitializeComponent();
        }
    }
}
